// ReadLater Extension - Background Script
// Sağ tık menüsü ile kaydetme (HTML içerik destekli)

const SERVER_URL = 'http://localhost:3000';

// Sağ tık menüsü oluştur
browser.contextMenus.create({
    id: 'save-to-readlater',
    title: '📚 ReadLater\'a Kaydet',
    contexts: ['page', 'link']
});

// Menü tıklaması
browser.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId !== 'save-to-readlater') return;

    // Link veya sayfa URL'si
    const url = info.linkUrl || info.pageUrl || tab.url;

    if (!url || (!url.startsWith('http://') && !url.startsWith('https://'))) {
        showNotification('Hata', 'Geçersiz URL');
        return;
    }

    // Eğer sayfa üzerindeyse (link değil), HTML içeriği al
    if (!info.linkUrl && tab && tab.id) {
        try {
            // Sayfanın HTML içeriğini al (Firefox manifest v2 uyumlu)
            const results = await browser.tabs.executeScript(tab.id, {
                code: 'document.documentElement.outerHTML'
            });

            const html = results && results[0];

            if (html && html.length > 500) {
                // Sayfa HTML'i ile kaydet (sunucu tarafında parsing)
                await saveWithContent(url, html);
                return;
            }
        } catch (e) {
            console.log('[ReadLater] HTML alınamadı, URL ile kaydet:', e.message);
        }
    }

    // Link tıklandıysa veya HTML alınamadıysa sadece URL ile kaydet
    await saveWithUrl(url);
});

// Ortak API çağrı fonksiyonu
async function makeRequest(endpoint, body, fallbackTitle) {
    try {
        const response = await fetch(`${SERVER_URL}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        const data = await response.json();

        if (data.success) {
            showNotification('Kaydedildi! ✅', data.article?.title || fallbackTitle);
        } else if (data.exists) {
            showNotification('Zaten Kayıtlı', data.article?.title || fallbackTitle);
        } else {
            showNotification('Hata ❌', data.error);
        }
    } catch (error) {
        showNotification('Bağlantı Hatası', 'Sunucuya bağlanılamadı');
    }
}

// URL ile kaydet
async function saveWithUrl(url) {
    await makeRequest('/api/save', { url }, url);
}

// HTML içerik ile kaydet (Cloudflare korumalı siteler için)
async function saveWithContent(url, html) {
    await makeRequest('/api/save-with-content', { url, html }, url);
}

// Bildirim göster
function showNotification(title, message) {
    browser.notifications.create({
        type: 'basic',
        iconUrl: 'icon48.png',
        title: title,
        message: message
    });
}
